Javier Mauricio Jara Valle
